SELECT DISTINCT(titleType)
FROM title_basics;
