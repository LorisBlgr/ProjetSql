SELECT AVG(runtimeMinutes) 
FROM title_basics 
WHERE titleType = 'movie';