SELECT startYear
FROM title_basics
WHERE primaryTitle="Superman";