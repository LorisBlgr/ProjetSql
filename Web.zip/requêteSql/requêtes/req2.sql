SELECT COUNT(primaryName)
FROM name_basics;