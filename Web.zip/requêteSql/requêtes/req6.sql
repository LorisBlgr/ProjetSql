SELECT primaryProfession
FROM name_basics
WHERE primaryName="Olivier Nakache";