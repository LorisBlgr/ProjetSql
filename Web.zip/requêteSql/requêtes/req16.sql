SELECT primaryTitle, MAX(runtimeMinutes) 
FROM title_basics;