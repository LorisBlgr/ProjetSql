SELECT originalTitle
FROM title_basics
WHERE primaryTitle="Jaws";