SELECT COUNT(primaryTitle)
FROM title_basics
WHERE runtimeMinutes>=180;